{{/* vim: set filetype=go-template: */}}
{{/*
Allow the release namespace to be overridden for multi-namespace deployments in combined charts
*/}}
{{- define "altinity-clickhouse-operator.namespace" -}}
  {{- if .Values.namespaceOverride -}}
    {{- .Values.namespaceOverride -}}
  {{- else -}}
    {{- .Release.Namespace -}}
  {{- end -}}
{{- end -}}

{{/*
Expand the name of the chart.
*/}}
{{- define "altinity-clickhouse-operator.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Create a default fully qualified app name.
We truncate at 63 chars because some Kubernetes name fields are limited to this (by the DNS naming spec).
If release name contains chart name it will be used as a full name.
*/}}
{{- define "altinity-clickhouse-operator.fullname" -}}
{{- if .Values.fullnameOverride -}}
{{- .Values.fullnameOverride | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- $name := default .Chart.Name .Values.nameOverride -}}
{{- if contains $name .Release.Name -}}
{{- .Release.Name | trunc 63 | trimSuffix "-" -}}
{{- else -}}
{{- printf "%s-%s" .Release.Name $name | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- end -}}
{{- end -}}

{{/*
Create chart name and version as used by the chart label.
*/}}
{{- define "altinity-clickhouse-operator.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}

{{/*
Common labels
*/}}
{{- define "altinity-clickhouse-operator.labels" -}}
helm.sh/chart: {{ include "altinity-clickhouse-operator.chart" . }}
{{ include "altinity-clickhouse-operator.selectorLabels" . }}
{{- if .Chart.AppVersion }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
{{- end }}
{{- if .Values.commonLabels }}
{{ toYaml .Values.commonLabels }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Pod template labels

The common labels minus helm.sh/chart and app.kubernetes.io/version. Both of those
change on a version bump, and anything inside the pod template feeds
pod-template-hash, so leaving them there rolls the Deployment on a chart bump even
when the image and the configuration are identical. They stay on the objects
themselves. commonLabels and managed-by are kept, since a user who sets
commonLabels reasonably expects them on the pods.
*/}}
{{- define "altinity-clickhouse-operator.podTemplateLabels" -}}
{{ include "altinity-clickhouse-operator.selectorLabels" . }}
{{- if .Values.commonLabels }}
{{ toYaml .Values.commonLabels }}
{{- end }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
{{- end -}}

{{/*
Selector labels
*/}}
{{- define "altinity-clickhouse-operator.selectorLabels" -}}
app.kubernetes.io/name: {{ include "altinity-clickhouse-operator.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}

{{/*
Common annotations
*/}}
{{- define "altinity-clickhouse-operator.annotations" -}}
meta.helm.sh/release-name: {{ .Release.Name }}
meta.helm.sh/release-namespace: {{ .Release.Namespace }}
{{- if .Values.commonAnnotations }}
{{ toYaml .Values.commonAnnotations }}
{{- end -}}
{{- end -}}

{{/*
Create the name of the service account to use
*/}}
{{- define "altinity-clickhouse-operator.serviceAccountName" -}}
    {{ default (include "altinity-clickhouse-operator.fullname" .) .Values.serviceAccount.name }}
{{- end -}}

{{/*
Create the tag for the docker image to use
*/}}
{{- define "altinity-clickhouse-operator.operator.tag" -}}
{{- .Values.operator.image.tag | default .Chart.AppVersion -}}
{{- end -}}

{{/*
Create the tag for the docker image to use
*/}}
{{- define "altinity-clickhouse-operator.metrics.tag" -}}
{{- .Values.metrics.image.tag | default .Chart.AppVersion -}}
{{- end -}}

{{/*
Env var overriding logger.v for a container, takes the logVerbosity value as context.
The value is checked as a string, so 0 is a valid value.
*/}}
{{- define "altinity-clickhouse-operator.loggerEnv" -}}
{{- $v := . -}}
{{- if and (not (kindIs "invalid" $v)) (ne (toString $v) "") -}}
- name: CHOP_LOGGER_V
  value: {{ toString $v | quote }}
{{- end -}}
{{- end -}}

{{/*
Env vars overriding logger options of the clickhouse-operator container.
*/}}
{{- define "altinity-clickhouse-operator.operator.loggerEnv" -}}
{{- include "altinity-clickhouse-operator.loggerEnv" .Values.operator.logVerbosity -}}
{{- end -}}

{{/*
Env vars overriding logger options of the metrics-exporter container.
*/}}
{{- define "altinity-clickhouse-operator.metrics.loggerEnv" -}}
{{- include "altinity-clickhouse-operator.loggerEnv" .Values.metrics.logVerbosity -}}
{{- end -}}

{{/*
altinity-clickhouse-operator.rawResource will create a resource template that can be
merged with each item in `.Values.additionalResources`.
*/}}
{{- define "altinity-clickhouse-operator.rawResource" -}}
metadata:
  labels:
    {{- include "altinity-clickhouse-operator.labels" . | nindent 4 }}
{{- end }}

{{/*
*/}}
{{- define "altinity-clickhouse-operator.configmap-data" }}
{{- $root := index . 0 }}
{{- $data := index . 1 }}
{{- if not $data -}}
null
{{ end }}
{{- range $k, $v := $data }}
{{- if not (kindIs "string" $v) }}
{{- $v = toYaml $v }}
{{- end }}
{{- tpl (toYaml (dict $k $v)) $root }}
{{ end }}
{{- end }}

{{/*
altinity-clickhouse-operator.configmap-files merges watchNamespaces into the
operator config before rendering the ConfigMap data block.

This exists because configs.files.config.yaml.watch.namespaces.include is
deep inside a nested structure — Helm's values merge cannot target it
directly. Instead we deepCopy the files map, patch the nested value in-place,
and pass the result to configmap-data.

Arguments (list): root context, configs.files, watchNamespaces list
*/}}
{{- define "altinity-clickhouse-operator.configmap-files" -}}
{{- $root := index . 0 -}}
{{- $files := deepCopy (index . 1) -}}
{{- $watchNamespaces := index . 2 -}}
{{- if $watchNamespaces -}}
  {{- $namespaces := dig "watch" "namespaces" "" (index $files "config.yaml") -}}
  {{- if kindIs "map" $namespaces -}}
    {{- $_ := set $namespaces "include" $watchNamespaces -}}
  {{- else -}}
    {{- fail "watchNamespaces is set but configs.files.\"config.yaml\".watch.namespaces is missing or null; cannot apply the namespace filter" -}}
  {{- end -}}
{{- end -}}
{{- include "altinity-clickhouse-operator.configmap-data" (list $root $files) -}}
{{- end -}}

{{/*
Compute a ConfigMap checksum from its data only, for the checksum/* pod annotations.
Hashing the whole manifest includes the helm.sh/chart label, which changes on every chart version
bump and would restart the operator when no configuration changed.

fromYaml decodes only the first document of a multi-document file, without reporting an error.
None of the generated ConfigMaps is multi-document, so this is latent rather than a live bug,
but it is a difference from the raw-include form this replaced.
*/}}
{{- define "altinity-clickhouse-operator.configMapContentHash" -}}
{{ pick (include (print .ctx.Template.BasePath .name) .ctx | fromYaml) "data" "binaryData" | toYaml | sha256sum }}
{{- end -}}
